<?php
defined('_JEXEC') or die;

class AgosmmapbuttonhelpViewButton extends JViewLegacy
{
	public function display($tpl = null)
	{
		parent::display($tpl);
	}
}
