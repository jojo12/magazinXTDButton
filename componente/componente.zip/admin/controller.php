<?php

defined('_JEXEC') or die;

class AgosmmapbuttonhelpController extends JControllerLegacy
{
	protected $default_view = 'button';

	public function display($cachable = false, $urlparams = array())
	{
		return parent::display();
	}
}
